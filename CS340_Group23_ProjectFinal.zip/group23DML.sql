-- ENROLLMENT PAGE QUERIES
-- Display enrollment - get enrollment in ID
SELECT * FROM enrollment_type;

-- Add enrollment 
INSERT INTO enrollment_type (type) VALUES ('?');

-- Delete enrollment - delete where enrollment_id = ?
DELETE FROM enrollment_type WHERE enrollment_id = '?';

-- Search enrollment - with enrollemnt type name like
SELECT * FROM enrollment_type WHERE type LIKE '?';

-- Edit enrollment -  get specific enrollment_id from enrollmnet table
SELECT enrollment_id, type FROM enrollment_type WHERE enrollment_id = '?';

-- Update enrollment - after edit
UPDATE enrollment_type SET type=? WHERE enrollment_id = '?';

-- STUDENT PAGE QUERIES
-- Display student page - function to display student table (all)
SELECT student.student_id, student.first_name, student.last_name, 
    enrollment_type.type, student.enrollment_qtr, student.enrollment_year 
    FROM student 
    LEFT JOIN enrollment_type ON enrollment_type.enrollment_id = student.enrollment_type;

-- Add student
INSERT INTO student (first_name, last_name, enrollment_type, 
        enrollment_qtr, enrollment_year) VALUES ('?','?','?','?','?');

-- Delete student
DELETE FROM student WHERE student_id = '?';

-- Edit student - function to get specific student id
SELECT student.student_id, student.first_name, student.last_name, 
    enrollment_type.type, student.enrollment_qtr, student.enrollment_year 
    FROM student 
    LEFT JOIN enrollment_type ON enrollment_type.enrollment_id = student.enrollment_type 
    WHERE student.student_id = '?';
    
-- Update student 
UPDATE student SET first_name='?', last_name='?', enrollment_type='?', enrollment_qtr='?', enrollment_year='?' WHERE student_id='?';

-- Filter student - to get student by specific year
SELECT student.student_id, student.first_name, student.last_name, 
    enrollment_type.type, student.enrollment_qtr, student.enrollment_year 
    FROM student 
	LEFT JOIN enrollment_type ON enrollment_type.enrollment_id = student.enrollment_type 
    WHERE student.enrollment_year = '?';
    
-- Search student - search student with first name like
SELECT student.student_id, student.first_name, student.last_name, 
    enrollment_type.type, student.enrollment_qtr, student.enrollment_year FROM student JOIN 
    enrollment_type ON enrollment_type.enrollment_id = student.enrollment_type 
    WHERE student.first_name LIKE '?';

-- STUDENT-CLASS PAGE QUERIES (M-TO-M)
-- Display student-class - function to get the student selection drop down in page
SELECT student_id, first_name, last_name FROM student;

-- Display student-class - function for class selection drop down for page
SELECT class_id, class_name FROM class;

-- Display student-class table - main table display
SELECT student.first_name, student.last_name, student_class.class_id, class.class_name 
    FROM student 
    LEFT JOIN student_class ON student_class.student_id = student.student_id
    LEFT JOIN class ON class.class_id = student_class.class_id;
    
-- Delete student-class
DELETE FROM student_class WHERE class_id = '?';

-- Add student-class
INSERT INTO student_class (student_id, class_id) VALUES ('?','?');

-- Filter student-class - function to get select specific year
SELECT student.first_name, student.last_name, student_class.class_id, class.class_name 
    FROM student 
    LEFT JOIN student_class ON student_class.student_id = student.student_id
    LEFT JOIN class ON class.class_id = student_class.class_id
    WHERE student_class.class_id = '?';
    
-- Search student-class - search student first_name like
SELECT student.first_name, student.last_name, student_class.class_id, class.class_name 
    FROM student 
    LEFT JOIN student_class ON student_class.student_id = student.student_id
    LEFT JOIN class ON class.class_id = student_class.class_id
    WHERE student.first_name LIKE '?';
    
-- INSTRUCTOR PAGE QUERIES
-- Display instructor
SELECT instructor.instructor_id, instructor.first_name, 
    instructor.last_name, academic_rank.name FROM instructor 
    LEFT JOIN academic_rank ON academic_rank.rank_id = instructor.academic_rank;
    
-- Display instructor - function to get academic_rank and rank_id drop down
SELECT * FROM academic_rank;

-- Add new instructor
INSERT INTO instructor (first_name, last_name, academic_rank) VALUES ('?','?','?');

-- Delete instructor
DELETE FROM instructor WHERE instructor_id = '?';

-- Filter instructor - filter by academic rank
SELECT instructor.instructor_id, instructor.first_name, 
    instructor.last_name, academic_rank.name FROM instructor 
    LEFT JOIN academic_rank ON academic_rank.rank_id = instructor.academic_rank
    WHERE instructor.academic_rank = '?';
    
-- Edit instructor
SELECT instructor.instructor_id, instructor.first_name, 
    instructor.last_name, academic_rank.name FROM instructor 
    LEFT JOIN academic_rank ON academic_rank.rank_id = instructor.academic_rank 
    WHERE instructor.instructor_id= '?';

-- Update instructor
UPDATE instructor SET first_name='?', last_name='?', academic_rank='?' WHERE instructor_id = '?';

-- Search instructor - where instructor first_name like
SELECT instructor.instructor_id, instructor.first_name, 
    instructor.last_name, academic_rank.name FROM instructor 
    LEFT JOIN academic_rank ON academic_rank.rank_id = instructor.academic_rank 
    WHERE instructor.first_name LIKE '?';

-- ACADEMIC RANK PAGE QUERIES
-- Display academic_rank
SELECT * FROM academic_rank;

-- Add academic_rank
INSERT INTO academic_rank (name) VALUES ('?');

-- Delete academic_rank
DELETE FROM academic_rank WHERE rank_id = '?';

-- Search academic_rank
SELECT * FROM academic_rank WHERE name LIKE '?';

-- Edit academic_rank
SELECT * FROM academic_rank WHERE rank_id= '?';

-- Update academic_rank
UPDATE academic_rank SET name=? WHERE rank_id = '?';

-- CLASS PAGE QUERIES
-- Display class - display class table
SELECT class.class_id, class.class_name, class.prerequisite, 
    class.qtr_offered, instructor.first_name, instructor.last_name
    FROM class
    LEFT JOIN instructor ON instructor.instructor_id = class.instructor;
    
-- Display class - function needed for degrees/instructors
Select instructor_id, first_name, last_name FROM instructor;

-- Add class
INSERT INTO class (class_name, prerequisite, qtr_offered, instructor) VALUES ('?', '?', '?', '?');

-- Delete class
DELETE FROM class WHERE class_id = '?';

-- Edit class - selecting specific class by ID
SELECT class.class_id, class.class_name, class.prerequisite, 
    class.qtr_offered, instructor.first_name, instructor.last_name
    FROM class
    LEFT JOIN instructor ON instructor.instructor_id = class.instructor
    WHERE class.class_id= '?';
    
-- Update class
UPDATE class SET class_name='?', prerequisite='?', qtr_offered='?', instructor='?' WHERE class_id = '?';

-- Search class - searching where instructor first_name like
SELECT class.class_id, class.class_name, class.prerequisite, 
    class.qtr_offered, instructor.first_name, instructor.last_name
    FROM class
    LEFT JOIN instructor ON instructor.instructor_id = class.instructor
    WHERE instructor.first_name LIKE '?';
    
-- Filter class - filter function by quarter
SELECT class.class_id, class.class_name, class.prerequisite, 
    class.qtr_offered, instructor.first_name, instructor.last_name
    FROM class
    LEFT JOIN instructor ON instructor.instructor_id = class.instructor
    WHERE class.qtr_offered= '?';

-- DEGREE PAGE QUERIES
-- Display degree
SELECT * FROM degree;

-- Display degree - but group-by - need this for drop-down
SELECT * FROM degree GROUP BY degree_type;

-- Add degree
INSERT INTO degree (degree_type, field) VALUES ('?', '?');

-- Delete degree
DELETE FROM degree WHERE degree_id = '?';

-- Edit degree - to select specific degree by id for updating
SELECT * FROM degree WHERE degree_id= '?';

-- Update degree
UPDATE degree SET degree_type=?, field=? WHERE degree_id = '?';

-- Filter degree - filter by degree type
SELECT * FROM degree WHERE degree_type= '?';

-- Search degree - degree where field name is like
SELECT * FROM degree WHERE field LIKE '?';

-- STUDENT-DEGREE PAGE QUERIES (M-TO-M)
-- Display student-degree - function for degrees selection drop-down
SELECT degree_id, degree_type, field FROM degree;

-- Display student-degree - function for student selection drop-down
Select student_id, first_name, last_name FROM student;

-- Display student-degree - function to display table 
SELECT student.first_name, student.last_name, student_degree.degree_id, degree.degree_type, degree.field 
    FROM student 
    LEFT JOIN student_degree ON student_degree.student_id = student.student_id
    LEFT JOIN degree ON degree.degree_id = student_degree.degree_id;
    
-- Add student-degree association
INSERT INTO student_degree (student_id, degree_id) VALUES ('?','?');

-- Delete student-degree association
DELETE FROM student_degree WHERE degree_id = '?';

-- Filter student-degree 
SELECT student.first_name, student.last_name, student_degree.degree_id, degree.degree_type, degree.field 
    FROM student 
    LEFT JOIN student_degree ON student_degree.student_id = student.student_id
    LEFT JOIN degree ON degree.degree_id = student_degree.degree_id
    WHERE student_degree.degree_id = '?';
    
-- Search student-degree - where student first name like
SELECT student.first_name, student.last_name, student_degree.degree_id, degree.degree_type, degree.field 
    FROM student 
    LEFT JOIN student_degree ON student_degree.student_id = student.student_id
    LEFT JOIN degree ON degree.degree_id = student_degree.degree_id
    WHERE student.first_name LIKE '?';
    






